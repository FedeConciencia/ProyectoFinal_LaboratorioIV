
package Modelo;

import java.time.LocalDate;


public class Cliente {
    
    //Variables/Atributos de clase:
    
    private long idCliente;
    private String nombre;
    private String apellido;
    private String dni;
    private LocalDate fechaNacimiento;
    private String telefono;
    private String email;
    private LocalDate fechaAlta;
    private LocalDate fechaBaja;
    private String estado;
    
    //Variables de Relacion:
    
    
    //Constructores:

    public Cliente() {
        
    }

    public Cliente(String nombre, String apellido, String dni, LocalDate fechaNacimiento, String telefono, String email, LocalDate fechaAlta, LocalDate fechaBaja, String estado) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.email = email;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
        this.estado = estado;
    }

    public Cliente(long idCliente, String nombre, String apellido, String dni, LocalDate fechaNacimiento, String telefono, String email, LocalDate fechaAlta, LocalDate fechaBaja, String estado) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.email = email;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
        this.estado = estado;
    }
    
    //Creo un controaldor sin variable fechaBaja para que se cree el default 0000-00-00 en la base de datos:

    public Cliente(String nombre, String apellido, String dni, LocalDate fechaNacimiento, String telefono, String email, LocalDate fechaAlta, String estado) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.email = email;
        this.fechaAlta = fechaAlta;
        this.estado = estado;
    }
    
    
    
    //Metodos Accesores(Getters and Setters):

    public long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(long idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "\nIdCliente: " + idCliente + "\nNombre: " + nombre + "\nApellido: " + apellido + 
                "\nDni: " + dni + "\nFechaNacimiento: " + fechaNacimiento + "\nTelefono: " + telefono + 
                "\nEmail: " + email + "\nFechaAlta: " + fechaAlta + "\nFechaBaja: " + fechaBaja + 
                "\nEstado: " + estado;
    }
    

    
}
