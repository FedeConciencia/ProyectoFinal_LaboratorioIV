
package Principal;

import Controlador.ControladorCliente;
import Modelo.Cliente;
import java.time.LocalDate;
import java.util.List;


public class Principal {
    
    //Gestionar las pruebas de los metodos:
    
    public static void main(String[] args) {
        
        //Testeo Cliente:
        
        /*
        
        //Metodo Insertar Cliente (Funciona Ok):
        
        ControladorCliente controlador = new ControladorCliente();
        
        Cliente cliente = new Cliente("Laura", "Raumundi", "633535353", LocalDate.of(2020,10,11), "2612622522", "laura@yahoo.com", LocalDate.of(2021,5,14), LocalDate.of(1900,1,1), "activo");
        
        controlador.insertarCliente(cliente);
        
        */
        
        /*
        
        //Metodo Actualizar Cliente (Funciona Ok):
        
        ControladorCliente controlador = new ControladorCliente();
        
        Cliente cliente = new Cliente(1L,"Diana", "Salmuera", "4432321233", LocalDate.of(2019,3,11), "2616722626", "laura@gmail.com", LocalDate.of(2020,2,13), LocalDate.of(2021,5,14), "inactivo");
        
        controlador.actualizarCliente(cliente);
        
        */
        
        /*
        
        //Metodo BuscaOne Cliente (Funciona Ok):
        
        ControladorCliente controlador = new ControladorCliente();
        
        Cliente cliente = controlador.buscarOneCliente(1L);
        
        System.out.println(cliente.toString());

        */
        
        /*
        
        //Metodo BuscaAll Cliente (Funciona Ok):
        
        ControladorCliente controlador = new ControladorCliente();
        
        List<Cliente> listaCliente = controlador.buscarAllCliente();
        
        for(Cliente item: listaCliente){
            
            System.out.println(item.toString());
            
        }

        */
        
        /*
        
        //Metodo eliminar Cliente (Funciona Ok):
        
        ControladorCliente controlador = new ControladorCliente();
        
        controlador.eliminarCliente(1L);

        */
        
    
    }
    

}

